//
//  ViewController.h
//  videoRecord
//
//  Created by lieyunye on 10/12/15.
//  Copyright © 2015 lieyunye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

