//
//  PipViewController.h
//  videoRecord
//
//  Created by lieyunye on 2017/1/13.
//  Copyright © 2017年 lieyunye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PipViewController : UIViewController

@end
