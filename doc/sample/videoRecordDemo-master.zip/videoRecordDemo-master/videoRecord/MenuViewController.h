//
//  MenuViewController.h
//  videoRecord
//
//  Created by lieyunye on 2017/1/12.
//  Copyright © 2017年 lieyunye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController

@end
